import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;



public class VisitorGame extends GameEngine {

    private HashMap<String, GuestRoomPlacement> guestRoomPlacements;

    private static final int WINDOW_WIDTH = 1920;
    private static final int WINDOW_HEIGHT = 1080;

    private Random random = new Random();

    private int currentDay;
    private GamePhase currentPhase;
    private SceneType currentScene;

    private GuestManager guestManager;
    private SafeHouseManager safeHouseManager;



    private HashMap<SceneType, Image> sceneImages;
    private HashMap<String, Image> characterImages;

    private Image dialogueOptionSpriteSheet;
    private Image[] dialogueOptionFrames;

    private int dialogueOptionFrameIndex = 0;
    private long lastDialogueOptionFrameTime = 0L;

    private static final int DIALOGUE_OPTION_FRAME_COUNT = 6;
    private static final int DIALOGUE_OPTION_FRAME_COLS = 3;
    private static final int DIALOGUE_OPTION_FRAME_ROWS = 2;
    private static final int DIALOGUE_OPTION_FRAME_W = 400;
    private static final int DIALOGUE_OPTION_FRAME_H = 103;

    private static final long DIALOGUE_OPTION_FRAME_INTERVAL = 120;



    private AudioClip knockSound;

    private HashSet<String> flags;

    private String message;

    private boolean showDialogue;
    private String activeGuestId;
    private boolean activeDialogueIsDay;
    private DialogueNode activeDialogueNode;
    private int activeDialogueLineIndex;
    private String pendingDialogueResult;

    private String outsideGuestId;
    private boolean outsideGuestVisible;

    private boolean flashBlackActive;
    private double flashBlackTimer;
    private double flashBlackDuration;
    private String pendingFlashAction;

    private boolean flashWhiteActive;
    private double flashWhiteTimer;
    private double flashWhiteDuration;
    private String pendingFlashWhiteAction;


    private int maxStamina;
    private int currentStamina;
    private boolean inspectionActive;
    private String inspectedGuestId;
    private InspectionFeatureType currentInspectionFeature;
    private String currentInspectionImageKey;


    private ArrayList<String> nightVisitorQueue;
    private HashMap<String, String> outsideGuestImageKeys;


    private boolean debugClickAreas = true;

    private static final String GUEST_NEIGHBOR = "neighbor";
    private static final String GUEST_DAUGHTER = "daughter";
    private static final String GUEST_FIREFIGHTER = "firefighter";
    private static final String GUEST_TEACHER = "teacher";
    private static final String GUEST_COAT_PERSON = "coat_person";
    private static final String GUEST_JUDGE_VISITOR = "judge_visitor";
    private static final String GUEST_WIDOW = "widow";
    private static final String GUEST_AUNTIE = "auntie";
    private static final String GUEST_PANIC_GIRL = "panic_girl";




    private static final String CHARACTER_NEIGHBOR_OUTSIDE = "neighbor_outside";
    private static final String CHARACTER_NEIGHBOR_DAY = "neighbor_day";
    private static final String CHARACTER_DAUGHTER_OUTSIDE = "daughter_outside";
    private static final String CHARACTER_FIREFIGHTER_OUTSIDE = "firefighter_outside";
    private static final String CHARACTER_TEACHER_OUTSIDE = "teacher_outside";
    private static final String CHARACTER_COAT_PERSON_OUTSIDE = "coat_person_outside";
    private static final String CHARACTER_JUDGE_VISITOR_OUTSIDE = "judge_visitor_outside";
    private static final String CHARACTER_WIDOW_OUTSIDE = "widow_outside";
    private static final String CHARACTER_AUNTIE_OUTSIDE = "auntie_outside";
    private static final String CHARACTER_PANIC_GIRL_OUTSIDE = "panic_girl_outside";


    private static final String CHARACTER_DAUGHTER_DAY = "daughter_day";
    private static final String CHARACTER_FIREFIGHTER_DAY = "firefighter_day";
    private static final String CHARACTER_TEACHER_DAY = "teacher_day";
    private static final String CHARACTER_COAT_PERSON_DAY = "coat_person_day";
    private static final String CHARACTER_TRASH_BAG = "trash_bag";
    private static final String CHARACTER_COAT_PERSON_CORPSE = "coat_person_corpse";
    private static final String CHARACTER_WIDOW_DAY = "widow_day";
    private static final String CHARACTER_AUNTIE_DAY = "auntie_day";
    private static final String CHARACTER_PANIC_GIRL_DAY = "panic_girl_day";

    private static final String CHARACTER_AUNTIE_CORPSE = "auntie_corpse";







    private static final String ACTION_TALK_GUEST_PREFIX = "talk_guest:";


    private static final String FLAG_KNOCK_HEARD = "knock_heard";
    private static final String FLAG_NEIGHBOR_INSIDE_HOUSE = "neighbor_inside_house";
    private static final String FLAG_NO_MORE_VISITORS_CONFIRMED = "no_more_visitors_confirmed";
    private static final String FLAG_NEIGHBOR_TALKED_MORNING = "neighbor_talked_morning";
    private static final String FLAG_NEIGHBOR_LEFT_WITH_DAUGHTER = "neighbor_left_with_daughter";
    private static final String FLAG_SECOND_NIGHT_STARTED = "second_night_started";
    private static final String FLAG_SECOND_NIGHT_VISITORS_DONE = "second_night_visitors_done";

    private static final String FLAG_DAUGHTER_VISITED = "daughter_visited";
    private static final String FLAG_FIREFIGHTER_VISITED = "firefighter_visited";
    private static final String FLAG_TEACHER_VISITED = "teacher_visited";
    private static final String FLAG_COAT_PERSON_VISITED = "coat_person_visited";
    private static final String FLAG_THIRD_NIGHT_STARTED = "third_night_started";
    private static final String FLAG_THIRD_NIGHT_VISITORS_DONE = "third_night_visitors_done";

    private static final String FLAG_JUDGE_VISITOR_VISITED = "judge_visitor_visited";
    private static final String FLAG_WIDOW_VISITED = "widow_visited";
    private static final String FLAG_AUNTIE_VISITED = "auntie_visited";
    private static final String FLAG_PANIC_GIRL_VISITED = "panic_girl_visited";

    private static final String FLAG_GAME_OVER = "game_over";




    private static final String ACTION_GO_YARD = "go_yard";
    private static final String ACTION_OPEN_GATE = "open_gate";
    private static final String ACTION_CHECK_EMPTY_GATE = "check_empty_gate";
    private static final String ACTION_GO_BEDROOM_NIGHT = "go_bedroom_night";
    private static final String ACTION_SLEEP = "sleep";
    private static final String ACTION_DAY_SLEEP = "day_sleep";
    private static final String FLASH_START_SECOND_NIGHT = "flash_start_second_night";
    private static final String FLASH_START_THIRD_NIGHT = "flash_start_third_night";
    private static final String FLASH_GAME_OVER_BY_JUDGE = "flash_game_over_by_judge";




    private static final String RESULT_NEIGHBOR_ENTER_HOUSE = "neighbor_enter_house";
    private static final String RESULT_FINISH_DAY_TALK = "finish_day_talk";
    private static final String RESULT_DAUGHTER_TAKE_NEIGHBOR = "daughter_take_neighbor";
    private static final String RESULT_JUDGE_VISITOR_DECISION = "judge_visitor_decision";


    private static final String RESULT_NIGHT_VISITOR_ALLOW_PREFIX = "night_visitor_allow:";
    private static final String RESULT_NIGHT_VISITOR_REJECT_PREFIX = "night_visitor_reject:";



    private static final String FLASH_REVEAL_OUTSIDE_GUEST = "flash_reveal_outside_guest";
    private static final String FLASH_SLEEP_TO_NEXT_MORNING = "flash_sleep_to_next_morning";
    private static final String FLASH_KILL_INSPECTED_GUEST = "flash_kill_inspected_guest";


    private static final String SPECIAL_INSPECT_FEATURES = "__inspect_features__";
    private static final String SPECIAL_ALLOW_CURRENT_GUEST = "__allow_current_guest__";
    private static final String SPECIAL_REJECT_CURRENT_GUEST = "__reject_current_guest__";
    private static final String SPECIAL_JUDGE_ANSWER_YES = "__judge_answer_yes__";
    private static final String SPECIAL_JUDGE_ANSWER_NO = "__judge_answer_no__";

    private static final String MESSAGE_SOMEONE_DIED = "闻到一股血腥味......好像有人死了。";
    private static final String MESSAGE_GAME_OVER = "你死了。游戏结束。";




    private static final String ACTION_GO_HALLWAY_DAY = "go_hallway_day";
    private static final String ACTION_GO_BEDROOM_DAY = "go_bedroom_day";
    private static final String ACTION_GO_KITCHEN_DAY = "go_kitchen_day";
    private static final String ACTION_GO_STORAGE_DAY = "go_storage_day";
    private static final String ACTION_GO_LIVING_ROOM_DAY = "go_living_room_day";


    private static final String INSPECT_TEACHER_TEETH = "teacher_teeth";
    private static final String INSPECT_TEACHER_HANDS = "teacher_hands";

    private static final String INSPECT_FIREFIGHTER_TEETH = "firefighter_teeth";
    private static final String INSPECT_FIREFIGHTER_HANDS = "firefighter_hands";

    private static final String INSPECT_COAT_PERSON_TEETH = "coat_person_teeth";
    private static final String INSPECT_COAT_PERSON_HANDS = "coat_person_hands";



    private static final int DIALOGUE_BOX_X = 1040;
    private static final int DIALOGUE_BOX_Y = 90;
    private static final int DIALOGUE_BOX_W = 760;
    private static final int DIALOGUE_BOX_H = 430;

    private static final int DIALOGUE_TEXT_X = 1090;
    private static final int DIALOGUE_TEXT_Y = 210;

    private static final int OPTION_BUTTON_W = 300;
    private static final int OPTION_BUTTON_H = 56;
    private static final int OPTION_BUTTON_GAP_X = 26;
    private static final int OPTION_BUTTON_GAP_Y = 18;
    private static final int OPTION_START_X = 1090;
    private static final int OPTION_START_Y = 370;
    private static final int OPTION_COLUMNS = 2;




    private void loadDialogueOptionFrames() {
        dialogueOptionSpriteSheet = loadImage("assets/UI/dialogue_talk.png");
        dialogueOptionFrames = new Image[DIALOGUE_OPTION_FRAME_COUNT];

        int index = 0;
        for (int row = 0; row < DIALOGUE_OPTION_FRAME_ROWS; row++) {
            for (int col = 0; col < DIALOGUE_OPTION_FRAME_COLS; col++) {
                dialogueOptionFrames[index++] = subImage(
                        dialogueOptionSpriteSheet,
                        col * DIALOGUE_OPTION_FRAME_W,
                        row * DIALOGUE_OPTION_FRAME_H,
                        DIALOGUE_OPTION_FRAME_W,
                        DIALOGUE_OPTION_FRAME_H
                );
            }
        }
    }



    @Override
    public void init() {
        initWindow();
        initGameState();
        initCollections();
        initManagers();
        initImages();
        initOutsideGuestImageKeys();
        initGuestRoomPlacements();
        initAudios();
        initGuests();
        startFirstNight();

    }

    @Override
    public void update(double dt) {

        updateDialogue(dt);
        updateMessage(dt);
        updateFlashBlack(dt);
        updateFlashWhite(dt);
        updateDialogueOptionAnimation();

    }

    @Override
    public void paintComponent() {
        drawBackgroundLayer();
        drawCharacterLayer();
        drawStaminaLayer();
        drawDialogueLayer();
        drawInspectionLayer();
        drawMessageLayer();
        drawDebugClickAreas();
        drawFlashBlackLayer();
        drawFlashWhiteLayer();
    }

    @Override
    public void mouseClicked(MouseEvent event) {

        handleMouseClick(event.getX(), event.getY());
    }

    private void initWindow() {
        setWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);
    }

    private void initGameState() {
        maxStamina = 0;
        currentStamina = 0;

        currentDay = 1;
        currentPhase = GamePhase.NIGHT;
        currentScene = SceneType.BEDROOM_NIGHT;

        message = "";

        showDialogue = false;
        activeGuestId = null;
        activeDialogueIsDay = false;
        activeDialogueNode = null;
        activeDialogueLineIndex = 0;
        pendingDialogueResult = null;

        outsideGuestId = null;
        outsideGuestVisible = false;

        flashBlackActive = false;
        flashBlackTimer = 0;
        flashBlackDuration = 0;
        pendingFlashAction = null;
        flashWhiteActive = false;
        flashWhiteTimer = 0;
        flashWhiteDuration = 0;
        pendingFlashWhiteAction = null;



        inspectionActive = false;
        inspectedGuestId = null;
        currentInspectionFeature = null;
        currentInspectionImageKey = null;

    }

    private void initCollections() {
        sceneImages = new HashMap<SceneType, Image>();
        characterImages = new HashMap<String, Image>();
        flags = new HashSet<String>();

        guestRoomPlacements = new HashMap<String, GuestRoomPlacement>();

        nightVisitorQueue = new ArrayList<String>();
        outsideGuestImageKeys = new HashMap<String, String>();
    }



    private void initManagers() {
        guestManager = new GuestManager();
        safeHouseManager = new SafeHouseManager();



    }

    private void initImages() {
        sceneImages.put(SceneType.BEDROOM_NIGHT, loadImage("assets/images/background/bedroom_night.png"));
        sceneImages.put(SceneType.YARD_NIGHT, loadImage("assets/images/background/yard_night.png"));
        sceneImages.put(SceneType.BEDROOM_DAY, loadImage("assets/images/background/bedroom_day.png"));
        sceneImages.put(SceneType.KITCHEN_DAY, loadImage("assets/images/background/kitchen_day.png"));
        sceneImages.put(SceneType.HALLWAY_DAY, loadImage("assets/images/background/hallway_day.png"));
        sceneImages.put(SceneType.STORAGE_DAY, loadImage("assets/images/background/storage_day.png"));
        sceneImages.put(SceneType.LIVING_ROOM_DAY, loadImage("assets/images/background/living_room_day.png"));
        characterImages.put(CHARACTER_NEIGHBOR_OUTSIDE, loadImage("assets/images/visit/neighbor_outside.png"));
        characterImages.put(CHARACTER_NEIGHBOR_DAY, loadImage("assets/images/dayguests/neighbor_day.png"));
        characterImages.put(CHARACTER_DAUGHTER_OUTSIDE, loadImage("assets/images/visit/daughter_outside.png"));
        characterImages.put(CHARACTER_FIREFIGHTER_OUTSIDE, loadImage("assets/images/visit/firefighter_outside.png"));
        characterImages.put(CHARACTER_TEACHER_OUTSIDE, loadImage("assets/images/visit/teacher_outside.png"));
        characterImages.put(CHARACTER_COAT_PERSON_OUTSIDE, loadImage("assets/images/visit/coat_person_outside.png"));
        characterImages.put(CHARACTER_JUDGE_VISITOR_OUTSIDE, loadImage("assets/images/visit/judge_visitor_outside.png"));
        characterImages.put(CHARACTER_WIDOW_OUTSIDE, loadImage("assets/images/visit/widow_outside.png"));
        characterImages.put(CHARACTER_AUNTIE_OUTSIDE, loadImage("assets/images/visit/auntie_outside.png"));
        characterImages.put(CHARACTER_PANIC_GIRL_OUTSIDE, loadImage("assets/images/visit/panic_girl_outside.png"));



        characterImages.put(CHARACTER_FIREFIGHTER_DAY, loadImage("assets/images/dayguests/firefighter_day.png"));
        characterImages.put(CHARACTER_TEACHER_DAY, loadImage("assets/images/dayguests/teacher_day.png"));
        characterImages.put(CHARACTER_COAT_PERSON_DAY, loadImage("assets/images/dayguests/coat_person_day.png"));
        characterImages.put(CHARACTER_WIDOW_DAY, loadImage("assets/images/dayguests/widow_day.png"));
        characterImages.put(CHARACTER_AUNTIE_DAY, loadImage("assets/images/dayguests/auntie_day.png"));
        characterImages.put(CHARACTER_PANIC_GIRL_DAY, loadImage("assets/images/dayguests/panic_girl_day.png"));
        characterImages.put(CHARACTER_TRASH_BAG, loadImage("assets/images/corpse/trash_bag.png"));
        characterImages.put(CHARACTER_COAT_PERSON_CORPSE, loadImage("assets/images/corpse/coat_person_corpse.png"));
        characterImages.put(CHARACTER_AUNTIE_CORPSE, loadImage("assets/images/corpse/auntie_corpse.png"));


        characterImages.put(INSPECT_TEACHER_TEETH, loadImage("assets/images/inspect/teacher_teeth.png"));
        characterImages.put(INSPECT_TEACHER_HANDS, loadImage("assets/images/inspect/teacher_hands.png"));

        characterImages.put(INSPECT_FIREFIGHTER_TEETH, loadImage("assets/images/inspect/firefighter_teeth.png"));
        characterImages.put(INSPECT_FIREFIGHTER_HANDS, loadImage("assets/images/inspect/firefighter_hands.png"));

        characterImages.put(INSPECT_COAT_PERSON_TEETH, loadImage("assets/images/inspect/coat_person_teeth.png"));
        characterImages.put(INSPECT_COAT_PERSON_HANDS, loadImage("assets/images/inspect/coat_person_hands.png"));







    }
    private void initOutsideGuestImageKeys() {
        outsideGuestImageKeys.put(GUEST_NEIGHBOR, CHARACTER_NEIGHBOR_OUTSIDE);
        outsideGuestImageKeys.put(GUEST_DAUGHTER, CHARACTER_DAUGHTER_OUTSIDE);
        outsideGuestImageKeys.put(GUEST_FIREFIGHTER, CHARACTER_FIREFIGHTER_OUTSIDE);
        outsideGuestImageKeys.put(GUEST_TEACHER, CHARACTER_TEACHER_OUTSIDE);
        outsideGuestImageKeys.put(GUEST_COAT_PERSON, CHARACTER_COAT_PERSON_OUTSIDE);
        outsideGuestImageKeys.put(GUEST_JUDGE_VISITOR, CHARACTER_JUDGE_VISITOR_OUTSIDE);
        outsideGuestImageKeys.put(GUEST_WIDOW, CHARACTER_WIDOW_OUTSIDE);
        outsideGuestImageKeys.put(GUEST_AUNTIE, CHARACTER_AUNTIE_OUTSIDE);
        outsideGuestImageKeys.put(GUEST_PANIC_GIRL, CHARACTER_PANIC_GIRL_OUTSIDE);

    }


    private void initAudios() {
        knockSound = loadAudio("assets/audios/knock.wav");
    }

    private void initGuests() {
        guestManager.initGuests();
    }

    private void initGuestRoomPlacements() {
        registerGuestRoomPlacement(
                GUEST_NEIGHBOR,
                DayRoomType.KITCHEN,
                CHARACTER_NEIGHBOR_DAY,
                1180,
                250,
                420,
                680
        );

        registerGuestRoomPlacement(
                GUEST_FIREFIGHTER,
                DayRoomType.LIVING_ROOM,
                CHARACTER_FIREFIGHTER_DAY,
                1050,
                260,
                380,
                650
        );

        registerGuestRoomPlacement(
                GUEST_TEACHER,
                DayRoomType.STORAGE,
                CHARACTER_TEACHER_DAY,
                980,
                260,
                380,
                650
        );

        registerGuestRoomPlacement(
                GUEST_COAT_PERSON,
                DayRoomType.KITCHEN,
                CHARACTER_COAT_PERSON_DAY,
                760,
                280,
                380,
                650
        );
        registerGuestRoomPlacement(
                GUEST_WIDOW,
                DayRoomType.LIVING_ROOM,
                CHARACTER_WIDOW_DAY,
                1450,
                260,
                320,
                650
        );

        registerGuestRoomPlacement(
                GUEST_AUNTIE,
                DayRoomType.STORAGE,
                CHARACTER_AUNTIE_DAY,
                1420,
                260,
                320,
                650
        );

        registerGuestRoomPlacement(
                GUEST_PANIC_GIRL,
                DayRoomType.KITCHEN,
                CHARACTER_PANIC_GIRL_DAY,
                1380,
                320,
                260,
                560
        );

    }


    private void registerGuestRoomPlacement(
            String guestId,
            DayRoomType room,
            String imageKey,
            int x,
            int y,
            int width,
            int height
    ) {
        String key = makeGuestRoomPlacementKey(guestId, room);

        guestRoomPlacements.put(
                key,
                new GuestRoomPlacement(
                        guestId,
                        room,
                        imageKey,
                        x,
                        y,
                        width,
                        height
                )
        );
    }


    private String makeGuestRoomPlacementKey(String guestId, DayRoomType room) {
        return guestId + "@" + room.name();
    }



    private void startFirstNight() {
        currentDay = 1;
        currentPhase = GamePhase.NIGHT;
        currentScene = SceneType.BEDROOM_NIGHT;

        safeHouseManager.setPlayerRoom(DayRoomType.BEDROOM);
        safeHouseManager.setCanSleep(false);

        addFlag(FLAG_KNOCK_HEARD);

        setOutsideGuest(GUEST_NEIGHBOR);

        playAudio(knockSound);
    }


    private void startNextMorning() {
        currentDay++;

        boolean someoneDied = false;

        if (currentDay == 3 || currentDay == 4) {
            someoneDied = resolveVisitorNightKill();
        }

        currentPhase = GamePhase.DAY;
        currentScene = SceneType.BEDROOM_DAY;

        safeHouseManager.setPlayerRoom(DayRoomType.BEDROOM);
        safeHouseManager.setCanSleep(false);

        clearOutsideGuest();

        setupMorningStamina();

        assignIndoorGuestsForMorning();

        clearMessage();
        closeDialogue();
        closeInspection();

        if (someoneDied) {
            showMessage(MESSAGE_SOMEONE_DIED);
        }
    }




    private void setupMorningStamina() {
        if (currentDay == 2) {
            maxStamina = 2;
            currentStamina = 2;
            return;
        }

        if (currentDay == 3) {
            maxStamina = 3;
            currentStamina = 3;
            return;
        }

        if (currentDay == 4) {
            maxStamina = 6;
            currentStamina = 6;
            return;
        }

        maxStamina = 0;
        currentStamina = 0;


    }


    private void assignIndoorGuestsForMorning() {
        if (hasFlag(FLAG_NEIGHBOR_INSIDE_HOUSE)
                && !hasFlag(FLAG_NEIGHBOR_LEFT_WITH_DAUGHTER)) {
            placeGuestInRoom(GUEST_NEIGHBOR, DayRoomType.KITCHEN);
        }

        keepAllowedGuestsInHouse();
    }

    private void keepAllowedGuestsInHouse() {
        // 目前先什么都不用写。
        // 因为 resultAllowNightVisitor() 里已经把允许进入的人设置成 insideHouse=true 了。
        // 第三天早上他们会根据自己的 currentRoom 自动显示。
    }



    private void placeGuestInRoom(String guestId, DayRoomType room) {
        Guest guest = guestManager.getGuest(guestId);

        if (guest == null) {
            return;
        }

        guest.setInsideHouse(true);
        guest.setCurrentRoom(room);
    }



    private void updateDialogueOptionAnimation() {
        long now = System.currentTimeMillis();

        if (dialogueOptionFrames != null
                && dialogueOptionFrames.length > 0
                && now - lastDialogueOptionFrameTime >= DIALOGUE_OPTION_FRAME_INTERVAL) {
            dialogueOptionFrameIndex = (dialogueOptionFrameIndex + 1) % dialogueOptionFrames.length;
            lastDialogueOptionFrameTime = now;
        }
    }





    private void updateDialogue(double dt) {
    }

    private void updateMessage(double dt) {
    }

    private void updateFlashBlack(double dt) {
        if (!flashBlackActive) {
            return;
        }

        flashBlackTimer += dt;

        if (flashBlackTimer >= flashBlackDuration) {
            finishFlashBlack();
        }
    }

    private void updateFlashWhite(double dt) {
        if (!flashWhiteActive) {
            return;
        }

        flashWhiteTimer += dt;

        if (flashWhiteTimer >= flashWhiteDuration) {
            finishFlashWhite();
        }
    }

    private void finishFlashWhite() {
        String resultAction = pendingFlashWhiteAction;

        flashWhiteActive = false;
        flashWhiteTimer = 0;
        flashWhiteDuration = 0;
        pendingFlashWhiteAction = null;

        handleFlashWhiteResult(resultAction);
    }

    private void handleFlashWhiteResult(String resultAction) {
        if (FLASH_KILL_INSPECTED_GUEST.equals(resultAction)) {
            killInspectedGuest();
        }
    }



    private void drawInspectionLayer() {
        if (!inspectionActive) {
            return;
        }

        changeColor(new Color(0, 0, 0, 210));
        drawSolidRectangle(0, 0, width(), height());

        Guest guest = guestManager.getGuest(inspectedGuestId);

        String title = "检查对象";

        if (guest != null) {
            title = "检查对象：" + guest.getName();
        }

        changeColor(white);
        drawText(120, 90, title, "Serif", 38);

        drawText(120, 145, "剩余体力：" + currentStamina + "/" + maxStamina, "Serif", 30);

        if (currentInspectionImageKey != null) {
            Image inspectImage = characterImages.get(currentInspectionImageKey);

            if (inspectImage != null) {
                drawImage(inspectImage, 520, 120, 880, 620);
            }
        } else {
            drawText(650, 360, "选择要检查的身体特征。", "Serif", 40);
        }

        drawInspectionButtons();
    }


    private void drawInspectionButtons() {
        Rectangle teethRect = getInspectTeethButtonRect();
        Rectangle handsRect = getInspectHandsButtonRect();
        Rectangle spareRect = getInspectSpareButtonRect();
        Rectangle killRect = getInspectKillButtonRect();
        Rectangle leaveRect = getInspectLeaveButtonRect();

        drawInspectionButton(teethRect, "检查牙齿");
        drawInspectionButton(handsRect, "检查双手");

        changeColor(new Color(255, 255, 255, 20));
        drawSolidRectangle(spareRect.x, spareRect.y, spareRect.width, spareRect.height);
        changeColor(new Color(255, 255, 255, 80));
        drawRectangle(spareRect.x, spareRect.y, spareRect.width, spareRect.height);
        changeColor(new Color(180, 180, 180, 180));
        drawText(spareRect.x + 18, spareRect.y + 38, "暂不检查", "Serif", 26);

        drawInspectionButton(killRect, "杀死他");
        drawInspectionButton(leaveRect, "不杀死他");
    }

    private void drawInspectionButton(Rectangle rect, String text) {
        changeColor(new Color(255, 255, 255, 45));
        drawSolidRectangle(rect.x, rect.y, rect.width, rect.height);

        changeColor(new Color(255, 255, 255, 100));
        drawRectangle(rect.x, rect.y, rect.width, rect.height);

        changeColor(white);
        drawText(rect.x + 18, rect.y + 38, text, "Serif", 26);
    }


    private Rectangle getInspectTeethButtonRect() {
        return new Rectangle(280, 820, 260, 60);
    }

    private Rectangle getInspectHandsButtonRect() {
        return new Rectangle(570, 820, 260, 60);
    }

    private Rectangle getInspectSpareButtonRect() {
        return new Rectangle(860, 820, 260, 60);
    }

    private Rectangle getInspectKillButtonRect() {
        return new Rectangle(1150, 820, 260, 60);
    }

    private Rectangle getInspectLeaveButtonRect() {
        return new Rectangle(1440, 820, 260, 60);
    }


    private void drawStaminaLayer() {
        if (currentPhase != GamePhase.DAY) {
            return;
        }

        if (maxStamina <= 0) {
            return;
        }

        int startX = 40;
        int startY = 40;
        int size = 42;
        int gap = 14;

        changeColor(new Color(0, 0, 0, 160));
        drawSolidRectangle(25, 25, 180, 90);

        changeColor(white);
        drawText(40, 58, "体力", "Serif", 26);

        for (int i = 0; i < maxStamina; i++) {
            int x = startX + i * (size + gap);
            int y = startY + 25;

            if (i < currentStamina) {
                changeColor(new Color(255, 230, 120));
                drawSolidRectangle(x, y, size, size);
            } else {
                changeColor(new Color(255, 255, 255, 35));
                drawSolidRectangle(x, y, size, size);
            }

            changeColor(new Color(255, 255, 255, 120));
            drawRectangle(x, y, size, size);
        }
    }


    private void drawBackgroundLayer() {
        clearBackground(width(), height());

        Image image = sceneImages.get(currentScene);

        if (image != null) {
            drawImage(image, 0, 0, width(), height());
        }
    }

    private void drawCharacterLayer() {
        drawOutsideGuestViewLayer();
        drawCurrentRoomGuestsLayer();
    }

    private void drawCurrentRoomGuestsLayer() {
        if (currentPhase != GamePhase.DAY) {
            return;
        }

        DayRoomType currentRoom = getCurrentDayRoomType();

        if (currentRoom == null) {
            return;
        }

        List<Guest> guests = guestManager.getAllGuests();

        for (int i = 0; i < guests.size(); i++) {
            Guest guest = guests.get(i);

            if (guest == null) {
                continue;
            }

            if (!guest.isInsideHouse()) {
                continue;
            }

            if (guest.getCurrentRoom() != currentRoom) {
                continue;
            }

            drawGuestInCurrentRoom(guest, currentRoom);
        }
    }


    private void drawGuestInCurrentRoom(Guest guest, DayRoomType room) {
        GuestRoomPlacement placement = getGuestRoomPlacement(guest.getId(), room);

        if (placement == null) {
            return;
        }

        String imageKey = placement.getImageKey();

        if (guest.isDead()) {
            if (guest.getCorpseImageKey() != null) {
                imageKey = guest.getCorpseImageKey();
            } else {
                imageKey = CHARACTER_TRASH_BAG;
            }
        }

        Image image = characterImages.get(imageKey);

        if (image == null) {
            return;
        }

        drawImage(
                image,
                placement.getX(),
                placement.getY(),
                placement.getWidth(),
                placement.getHeight()
        );
    }


    private GuestRoomPlacement getGuestRoomPlacement(String guestId, DayRoomType room) {
        String key = makeGuestRoomPlacementKey(guestId, room);
        return guestRoomPlacements.get(key);
    }

    private DayRoomType getCurrentDayRoomType() {
        if (currentScene == SceneType.BEDROOM_DAY) {
            return DayRoomType.BEDROOM;
        }

        if (currentScene == SceneType.HALLWAY_DAY) {
            return DayRoomType.HALLWAY;
        }

        if (currentScene == SceneType.KITCHEN_DAY) {
            return DayRoomType.KITCHEN;
        }

        if (currentScene == SceneType.STORAGE_DAY) {
            return DayRoomType.STORAGE;
        }

        if (currentScene == SceneType.LIVING_ROOM_DAY) {
            return DayRoomType.LIVING_ROOM;
        }
        return null;
    }



    private void drawOutsideGuestViewLayer() {
        if (currentScene != SceneType.YARD_NIGHT) {
            return;
        }

        if (!hasOutsideGuest()) {
            return;
        }

        if (!outsideGuestVisible) {
            return;
        }

        Image image = getOutsideGuestImage(outsideGuestId);

        if (image != null) {
            drawImage(image, 0, 0, width(), height());
        }
    }


    private void collectVisibleGuestClickAreas(ArrayList<ClickableArea> areas, DayRoomType room) {
        List<Guest> guests = guestManager.getAllGuests();

        for (int i = 0; i < guests.size(); i++) {
            Guest guest = guests.get(i);

            if (guest == null) {
                continue;
            }

            if (!guest.isInsideHouse()) {
                continue;
            }

            if (guest.isDead()) {
                continue;
            }


            if (guest.getCurrentRoom() != room) {
                continue;
            }

            GuestRoomPlacement placement = getGuestRoomPlacement(guest.getId(), room);

            if (placement == null) {
                continue;
            }

            areas.add(new ClickableArea(
                    ACTION_TALK_GUEST_PREFIX + guest.getId(),
                    placement.getX(),
                    placement.getY(),
                    placement.getWidth(),
                    placement.getHeight()
            ));
        }
    }





    private Image getOutsideGuestImage(String guestId) {
        String imageKey = outsideGuestImageKeys.get(guestId);

        if (imageKey == null) {
            return null;
        }

        return characterImages.get(imageKey);
    }



    private void drawDialogueLayer() {
        if (!showDialogue || activeDialogueNode == null) {
            return;
        }

        drawDialogueBox();

        if (shouldDrawCurrentDialogueLine()) {
            drawDialogueLine();
        }

        if (shouldDrawDialogueOptions()) {
            drawDialogueOptions();
        }
    }

    private boolean shouldDrawCurrentDialogueLine() {
        if (activeDialogueNode == null) {
            return false;
        }

        return activeDialogueLineIndex < activeDialogueNode.getLineCount();
    }

    private boolean shouldDrawDialogueOptions() {
        if (activeDialogueNode == null) {
            return false;
        }

        if (!activeDialogueNode.hasOptions()) {
            return false;
        }

        int lastLineIndex = activeDialogueNode.getLineCount() - 1;

        return activeDialogueLineIndex >= lastLineIndex;
    }



    private void drawDialogueBox() {
        changeColor(new Color(0, 0, 0, 205));
        drawSolidRectangle(
                DIALOGUE_BOX_X,
                DIALOGUE_BOX_Y,
                DIALOGUE_BOX_W,
                DIALOGUE_BOX_H
        );
    }


    private void drawDialogueLine() {
        String line = activeDialogueNode.getLine(activeDialogueLineIndex);

        changeColor(white);
        drawText(
                DIALOGUE_TEXT_X,
                DIALOGUE_TEXT_Y,
                line,
                "Serif",
                34
        );
    }


    private void drawDialogueOptions() {
        if (activeDialogueNode == null) {
            return;
        }

        List<DialogueOption> options = activeDialogueNode.getOptions();

        if (options == null || options.isEmpty()) {
            return;
        }

        for (int i = 0; i < options.size(); i++) {
            DialogueOption option = options.get(i);
            Rectangle rect = getDialogueOptionRect(i);

            if (dialogueOptionSpriteSheet != null) {
                changeColor(white);
                drawImage(
                        dialogueOptionSpriteSheet,
                        rect.x,
                        rect.y,
                        rect.width,
                        rect.height
                );
            } else {
                changeColor(new Color(255, 0, 0, 180));
                drawSolidRectangle(rect.x, rect.y, rect.width, rect.height);
            }

            changeColor(white);
            drawText(
                    rect.x + 18,
                    rect.y + 37,
                    option.getText(),
                    "Serif",
                    26
            );
        }
    }








    private Rectangle getDialogueOptionRect(int optionIndex) {
        int col = optionIndex % OPTION_COLUMNS;
        int row = optionIndex / OPTION_COLUMNS;

        int x = OPTION_START_X + col * (OPTION_BUTTON_W + OPTION_BUTTON_GAP_X);
        int y = OPTION_START_Y + row * (OPTION_BUTTON_H + OPTION_BUTTON_GAP_Y);

        return new Rectangle(
                x,
                y,
                OPTION_BUTTON_W,
                OPTION_BUTTON_H
        );
    }



    private void drawMessageLayer() {
        if (!hasMessage()) {
            return;
        }

        changeColor(new Color(0, 0, 0, 190));
        drawSolidRectangle(620, 430, 720, 150);

        changeColor(white);
        drawText(680, 520, message, "Serif", 34);
    }

    private void drawFlashBlackLayer() {
        if (!flashBlackActive) {
            return;
        }

        int alpha = getFlashBlackAlpha();

        changeColor(new Color(0, 0, 0, alpha));
        drawSolidRectangle(0, 0, width(), height());
    }

    private int getFlashBlackAlpha() {
        if (flashBlackDuration <= 0) {
            return 255;
        }

        double half = flashBlackDuration / 2.0;
        double progress;

        if (flashBlackTimer <= half) {
            progress = flashBlackTimer / half;
        } else {
            progress = 1.0 - ((flashBlackTimer - half) / half);
        }

        if (progress < 0) {
            progress = 0;
        }

        if (progress > 1) {
            progress = 1;
        }

        return (int)(progress * 255);
    }

    private void drawFlashWhiteLayer() {
        if (!flashWhiteActive) {
            return;
        }

        int alpha = getFlashWhiteAlpha();

        changeColor(new Color(255, 255, 255, alpha));
        drawSolidRectangle(0, 0, width(), height());
    }

    private int getFlashWhiteAlpha() {
        if (flashWhiteDuration <= 0) {
            return 255;
        }

        double half = flashWhiteDuration / 2.0;
        double progress;

        if (flashWhiteTimer <= half) {
            progress = flashWhiteTimer / half;
        } else {
            progress = 1.0 - ((flashWhiteTimer - half) / half);
        }

        if (progress < 0) {
            progress = 0;
        }

        if (progress > 1) {
            progress = 1;
        }

        return (int)(progress * 255);
    }


    private void drawDebugClickAreas() {
        if (!debugClickAreas) {
            return;
        }

        if (showDialogue || hasMessage() || flashBlackActive || flashWhiteActive || inspectionActive) {
            return;
        }


        ArrayList<ClickableArea> areas = getActiveClickAreas();

        changeColor(new Color(255, 255, 255, 40));

        for (ClickableArea area : areas) {
            drawSolidRectangle(area.getX(), area.getY(), area.getWidth(), area.getHeight());
        }
    }

    private void handleMouseClick(int mx, int my) {

        if (hasFlag(FLAG_GAME_OVER)) {
            return;
        }


        if (flashBlackActive || flashWhiteActive) {
            return;
        }

        if (inspectionActive) {
            handleInspectionClick(mx, my);
            return;
        }

        if (showDialogue) {
            handleDialogueClick(mx, my);
            return;
        }

        if (hasMessage()) {
            clearMessage();
            return;
        }

        handleSceneClick(mx, my);
    }

    private void handleInspectionClick(int mx, int my) {
        if (isInsideRect(mx, my,
                getInspectTeethButtonRect().x,
                getInspectTeethButtonRect().y,
                getInspectTeethButtonRect().width,
                getInspectTeethButtonRect().height)) {
            inspectCurrentGuestFeature(InspectionFeatureType.TEETH);
            return;
        }

        if (isInsideRect(mx, my,
                getInspectHandsButtonRect().x,
                getInspectHandsButtonRect().y,
                getInspectHandsButtonRect().width,
                getInspectHandsButtonRect().height)) {
            inspectCurrentGuestFeature(InspectionFeatureType.HANDS);
            return;
        }

        if (isInsideRect(mx, my,
                getInspectKillButtonRect().x,
                getInspectKillButtonRect().y,
                getInspectKillButtonRect().width,
                getInspectKillButtonRect().height)) {
            killInspectedGuestWithFlash();
            return;
        }

        if (isInsideRect(mx, my,
                getInspectLeaveButtonRect().x,
                getInspectLeaveButtonRect().y,
                getInspectLeaveButtonRect().width,
                getInspectLeaveButtonRect().height)) {
            closeInspection();
        }
    }

    private void inspectCurrentGuestFeature(InspectionFeatureType featureType) {
        if (!inspectionActive) {
            return;
        }

        if (currentStamina <= 0) {
            showMessage("你已经没有体力继续检查了。");
            return;
        }

        Guest guest = guestManager.getGuest(inspectedGuestId);

        if (guest == null) {
            closeInspection();
            return;
        }

        if (guest.isDead()) {
            showMessage("他已经死了。");
            closeInspection();
            return;
        }

        GuestFeatures features = guest.getFeatures();

        if (features == null) {
            showMessage("没有可检查的特征。");
            return;
        }

        currentStamina--;

        currentInspectionFeature = featureType;

        if (featureType == InspectionFeatureType.TEETH) {
            currentInspectionImageKey = features.getTeethImageKey();
            return;
        }

        if (featureType == InspectionFeatureType.HANDS) {
            currentInspectionImageKey = features.getHandsImageKey();
            return;
        }

        if (featureType == InspectionFeatureType.EYES) {
            currentInspectionImageKey = features.getEyesImageKey();
            return;
        }

        if (featureType == InspectionFeatureType.EARS) {
            currentInspectionImageKey = features.getEarsImageKey();
        }
    }

    private void closeInspection() {
        inspectionActive = false;
        inspectedGuestId = null;
        currentInspectionFeature = null;
        currentInspectionImageKey = null;
    }

    private void killInspectedGuestWithFlash() {
        if (!inspectionActive) {
            return;
        }

        Guest guest = guestManager.getGuest(inspectedGuestId);

        if (guest == null) {
            closeInspection();
            return;
        }

        if (guest.isDead()) {
            closeInspection();
            return;
        }

        startFlashWhite(0.35, FLASH_KILL_INSPECTED_GUEST);
    }

    private void killInspectedGuest() {
        Guest guest = guestManager.getGuest(inspectedGuestId);

        if (guest == null) {
            closeInspection();
            return;
        }

        guest.setDead(true);

        if (guest.isHuman()) {
            guest.setCorpseImageKey(CHARACTER_TRASH_BAG);
        } else if (guest.isVisitor()) {
            guest.setCorpseImageKey(getVisitorCorpseImageKey(guest.getId()));
        } else {
            guest.setCorpseImageKey(CHARACTER_TRASH_BAG);
        }

        closeInspection();
    }

    private String getVisitorCorpseImageKey(String guestId) {
        if (GUEST_COAT_PERSON.equals(guestId)) {
            return CHARACTER_COAT_PERSON_CORPSE;
        }

        if (GUEST_AUNTIE.equals(guestId)) {
            return CHARACTER_AUNTIE_CORPSE;
        }

        return CHARACTER_TRASH_BAG;
    }


    private void startFlashWhite(double duration, String resultAction) {
        flashWhiteActive = true;
        flashWhiteTimer = 0;
        flashWhiteDuration = duration;
        pendingFlashWhiteAction = resultAction;
    }


    private void handleSceneClick(int mx, int my) {
        ArrayList<ClickableArea> areas = getActiveClickAreas();

        for (ClickableArea area : areas) {
            if (area.contains(mx, my)) {
                handleAction(area.getActionId());
                return;
            }
        }
    }

    private void handleAction(String actionId) {

        if (actionId.startsWith(ACTION_TALK_GUEST_PREFIX)) {
            String guestId = actionId.substring(ACTION_TALK_GUEST_PREFIX.length());
            actionTalkGuestDay(guestId);
            return;
        }


        if (ACTION_GO_YARD.equals(actionId)) {
            actionGoYard();
            return;
        }

        if (ACTION_OPEN_GATE.equals(actionId)) {
            actionOpenGate();
            return;
        }

        if (ACTION_CHECK_EMPTY_GATE.equals(actionId)) {
            actionCheckEmptyGate();
            return;
        }

        if (ACTION_GO_BEDROOM_NIGHT.equals(actionId)) {
            actionGoBedroomNight();
            return;
        }

        if (ACTION_SLEEP.equals(actionId)) {
            actionSleep();
            return;
        }

        if (ACTION_GO_HALLWAY_DAY.equals(actionId)) {
            actionGoHallwayDay();
            return;
        }

        if (ACTION_GO_BEDROOM_DAY.equals(actionId)) {
            actionGoBedroomDay();
            return;
        }

        if (ACTION_GO_LIVING_ROOM_DAY.equals(actionId)) {
            actionGoLivingRoomDay();
            return;
        }


        if (ACTION_GO_KITCHEN_DAY.equals(actionId)) {
            actionGoKitchenDay();
            return;
        }

        if (ACTION_GO_STORAGE_DAY.equals(actionId)) {
            actionGoStorageDay();
            return;
        }

        if (ACTION_DAY_SLEEP.equals(actionId)) {
            actionDaySleep();
            return;
        }



    }

    private void actionDaySleep() {
        if (currentPhase != GamePhase.DAY) {
            return;
        }

        if (currentScene != SceneType.BEDROOM_DAY) {
            return;
        }

        if (!isStaminaEmpty()) {
            showMessage("你还不困。先把今天该做的事做完。");
            return;
        }

        if (currentDay == 2) {
            startFlashBlack(0.8, FLASH_START_SECOND_NIGHT);
            return;
        }

        if (currentDay == 3) {
            startFlashBlack(0.8, FLASH_START_THIRD_NIGHT);
            return;
        }

        showMessage("现在还不能睡。");
    }




    private void actionTalkGuestDay(String guestId) {
        Guest guest = guestManager.getGuest(guestId);

        if (guest == null) {
            return;
        }

        guest.setTalkedToday(true);

        startGuestDialogue(
                guestId,
                true,
                getDayDialogueResultForGuest(guestId)
        );
    }

    private String getDayDialogueResultForGuest(String guestId) {
        if (GUEST_NEIGHBOR.equals(guestId)) {
            return RESULT_FINISH_DAY_TALK;
        }

        return null;
    }


    private void actionGoLivingRoomDay() {
        currentScene = SceneType.LIVING_ROOM_DAY;
        safeHouseManager.setPlayerRoom(DayRoomType.LIVING_ROOM);
    }

    private void actionGoHallwayDay() {
        currentScene = SceneType.HALLWAY_DAY;
        safeHouseManager.setPlayerRoom(DayRoomType.HALLWAY);
    }

    private void actionGoBedroomDay() {
        currentScene = SceneType.BEDROOM_DAY;
        safeHouseManager.setPlayerRoom(DayRoomType.BEDROOM);
    }

    private void actionGoKitchenDay() {
        currentScene = SceneType.KITCHEN_DAY;
        safeHouseManager.setPlayerRoom(DayRoomType.KITCHEN);
    }

    private void actionGoStorageDay() {
        currentScene = SceneType.STORAGE_DAY;
        safeHouseManager.setPlayerRoom(DayRoomType.STORAGE);
    }


    private void actionGoYard() {
        currentScene = SceneType.YARD_NIGHT;
        safeHouseManager.setPlayerRoom(DayRoomType.YARD);
    }


    private void actionOpenGate() {
        if (!hasOutsideGuest()) {
            actionCheckEmptyGate();
            return;
        }

        startFlashBlack(0.55, FLASH_REVEAL_OUTSIDE_GUEST);
    }


    private void actionCheckEmptyGate() {
        addFlag(FLAG_NO_MORE_VISITORS_CONFIRMED);
    }

    private void actionGoBedroomNight() {
        currentScene = SceneType.BEDROOM_NIGHT;
        safeHouseManager.setPlayerRoom(DayRoomType.BEDROOM);
    }

    private void actionSleep() {
        if (!canSleepNow()) {
            return;
        }

        startFlashBlack(0.8, FLASH_SLEEP_TO_NEXT_MORNING);
    }

    private void actionGoKitchen() {
        currentScene = SceneType.KITCHEN_DAY;
        safeHouseManager.setPlayerRoom(DayRoomType.KITCHEN);
    }



    private void startFlashBlack(double duration, String resultAction) {
        flashBlackActive = true;
        flashBlackTimer = 0;
        flashBlackDuration = duration;
        pendingFlashAction = resultAction;
    }

    private void finishFlashBlack() {
        String resultAction = pendingFlashAction;

        flashBlackActive = false;
        flashBlackTimer = 0;
        flashBlackDuration = 0;
        pendingFlashAction = null;

        handleFlashBlackResult(resultAction);
    }

    private void handleFlashBlackResult(String resultAction) {
        if (FLASH_REVEAL_OUTSIDE_GUEST.equals(resultAction)) {
            revealOutsideGuestAndStartDialogue();
            return;
        }

        if (FLASH_SLEEP_TO_NEXT_MORNING.equals(resultAction)) {
            startNextMorning();
            return;
        }

        if (FLASH_START_SECOND_NIGHT.equals(resultAction)) {
            startSecondNight();
            return;
        }

        if (FLASH_START_THIRD_NIGHT.equals(resultAction)) {
            startThirdNight();
            return;
        }

        if (FLASH_GAME_OVER_BY_JUDGE.equals(resultAction)) {
            triggerGameOver();
        }
    }
    private void triggerGameOver() {
        addFlag(FLAG_GAME_OVER);
        showMessage(MESSAGE_GAME_OVER);
    }



    private void startSecondNight() {
        currentDay = 2;
        currentPhase = GamePhase.NIGHT;
        currentScene = SceneType.BEDROOM_NIGHT;

        safeHouseManager.setPlayerRoom(DayRoomType.BEDROOM);
        safeHouseManager.setCanSleep(false);

        maxStamina = 0;
        currentStamina = 0;

        clearMessage();
        closeDialogue();

        addFlag(FLAG_SECOND_NIGHT_STARTED);

        setupSecondNightVisitors();
    }

    private void setupSecondNightVisitors() {
        nightVisitorQueue.clear();

        nightVisitorQueue.add(GUEST_DAUGHTER);
        nightVisitorQueue.add(GUEST_FIREFIGHTER);
        nightVisitorQueue.add(GUEST_TEACHER);
        nightVisitorQueue.add(GUEST_COAT_PERSON);

        advanceToNextNightVisitor();
    }

    private void setupThirdNightVisitors() {
        nightVisitorQueue.clear();

        nightVisitorQueue.add(GUEST_JUDGE_VISITOR);
        nightVisitorQueue.add(GUEST_WIDOW);
        nightVisitorQueue.add(GUEST_AUNTIE);
        nightVisitorQueue.add(GUEST_PANIC_GIRL);

        advanceToNextNightVisitor();
    }


    private void advanceToNextThirdNightVisitor() {
        clearOutsideGuest();

        if (nightVisitorQueue.isEmpty()) {
            addFlag(FLAG_THIRD_NIGHT_VISITORS_DONE);
            return;
        }

        String nextGuestId = nightVisitorQueue.remove(0);

        setOutsideGuest(nextGuestId);
        addFlag(FLAG_KNOCK_HEARD);

        playAudio(knockSound);
    }


    private void startThirdNight() {
        currentDay = 3;
        currentPhase = GamePhase.NIGHT;
        currentScene = SceneType.BEDROOM_NIGHT;

        safeHouseManager.setPlayerRoom(DayRoomType.BEDROOM);
        safeHouseManager.setCanSleep(false);

        maxStamina = 0;
        currentStamina = 0;

        clearMessage();
        closeDialogue();
        closeInspection();

        addFlag(FLAG_THIRD_NIGHT_STARTED);

        setupThirdNightVisitors();
    }



    private void advanceToNextNightVisitor() {
        clearOutsideGuest();

        if (nightVisitorQueue.isEmpty()) {
            if (currentDay == 2 && currentPhase == GamePhase.NIGHT) {
                addFlag(FLAG_SECOND_NIGHT_VISITORS_DONE);
            }

            if (currentDay == 3 && currentPhase == GamePhase.NIGHT) {
                addFlag(FLAG_THIRD_NIGHT_VISITORS_DONE);
            }
            return;
        }

        String nextGuestId = nightVisitorQueue.remove(0);

        setOutsideGuest(nextGuestId);
        addFlag(FLAG_KNOCK_HEARD);

        playAudio(knockSound);
    }




    private void revealOutsideGuestAndStartDialogue() {
        if (!hasOutsideGuest()) {
            return;
        }

        outsideGuestVisible = true;

        if (GUEST_NEIGHBOR.equals(outsideGuestId)) {
            startGuestDialogue(
                    GUEST_NEIGHBOR,
                    false,
                    RESULT_NEIGHBOR_ENTER_HOUSE
            );
            return;
        }

        if (GUEST_DAUGHTER.equals(outsideGuestId)) {
            startGuestDialogue(
                    GUEST_DAUGHTER,
                    false,
                    RESULT_DAUGHTER_TAKE_NEIGHBOR
            );
            return;
        }

        if (GUEST_JUDGE_VISITOR.equals(outsideGuestId)) {
            startGuestDialogue(
                    GUEST_JUDGE_VISITOR,
                    false,
                    RESULT_JUDGE_VISITOR_DECISION
            );
            return;
        }

        startGuestDialogue(
                outsideGuestId,
                false,
                null
        );
    }


    private void resultDaughterTakeNeighbor() {
        addFlag(FLAG_DAUGHTER_VISITED);
        addFlag(FLAG_NEIGHBOR_LEFT_WITH_DAUGHTER);

        Guest neighbor = guestManager.getGuest(GUEST_NEIGHBOR);

        if (neighbor != null) {
            neighbor.setInsideHouse(false);
            neighbor.setCurrentRoom(null);
        }

        Guest daughter = guestManager.getGuest(GUEST_DAUGHTER);

        if (daughter != null) {
            daughter.setInsideHouse(false);
            daughter.setCurrentRoom(null);
        }

        clearOutsideGuest();

        currentScene = SceneType.YARD_NIGHT;

        advanceToNextNightVisitor();
    }

    private void resultAllowNightVisitor(String guestId) {
        markNightVisitorVisited(guestId);

        Guest guest = guestManager.getGuest(guestId);

        if (guest != null) {
            guest.setInsideHouse(true);
            guest.setCurrentRoom(getDefaultRoomForNightVisitor(guestId));
        }

        clearOutsideGuest();

        currentScene = SceneType.YARD_NIGHT;

        advanceToNextNightVisitor();
    }

    private void resultRejectNightVisitor(String guestId) {
        markNightVisitorVisited(guestId);

        Guest guest = guestManager.getGuest(guestId);

        if (guest != null) {
            guest.setInsideHouse(false);
            guest.setCurrentRoom(null);
        }

        clearOutsideGuest();

        currentScene = SceneType.YARD_NIGHT;

        advanceToNextNightVisitor();
    }

    private void markNightVisitorVisited(String guestId) {
        if (GUEST_FIREFIGHTER.equals(guestId)) {
            addFlag(FLAG_FIREFIGHTER_VISITED);
            return;
        }

        if (GUEST_TEACHER.equals(guestId)) {
            addFlag(FLAG_TEACHER_VISITED);
            return;
        }

        if (GUEST_COAT_PERSON.equals(guestId)) {
            addFlag(FLAG_COAT_PERSON_VISITED);
            return;
        }

        if (GUEST_WIDOW.equals(guestId)) {
            addFlag(FLAG_WIDOW_VISITED);
            return;
        }

        if (GUEST_AUNTIE.equals(guestId)) {
            addFlag(FLAG_AUNTIE_VISITED);
            return;
        }

        if (GUEST_PANIC_GIRL.equals(guestId)) {
            addFlag(FLAG_PANIC_GIRL_VISITED);
        }
    }


    private DayRoomType getDefaultRoomForNightVisitor(String guestId) {
        if (GUEST_FIREFIGHTER.equals(guestId)) {
            return DayRoomType.LIVING_ROOM;
        }

        if (GUEST_TEACHER.equals(guestId)) {
            return DayRoomType.STORAGE;
        }

        if (GUEST_COAT_PERSON.equals(guestId)) {
            return DayRoomType.KITCHEN;
        }

        if (GUEST_WIDOW.equals(guestId)) {
            return DayRoomType.LIVING_ROOM;
        }

        if (GUEST_AUNTIE.equals(guestId)) {
            return DayRoomType.STORAGE;
        }

        if (GUEST_PANIC_GIRL.equals(guestId)) {
            return DayRoomType.KITCHEN;
        }

        return DayRoomType.LIVING_ROOM;
    }




    private void startGuestDialogue(String guestId, boolean dayDialogue, String resultId) {
        Guest guest = guestManager.getGuest(guestId);

        if (guest == null) {
            return;
        }

        DialogueNode startNode;

        if (dayDialogue) {
            startNode = guest.getDayStartDialogueNode();
        } else {
            startNode = guest.getStartDialogueNode();
        }

        if (startNode == null) {
            return;
        }

        activeGuestId = guestId;
        activeDialogueIsDay = dayDialogue;
        activeDialogueNode = startNode;
        activeDialogueLineIndex = 0;
        pendingDialogueResult = resultId;
        showDialogue = true;
    }

    private void handleDialogueClick(int mx, int my) {
        if (activeDialogueNode == null) {
            closeDialogue();
            return;
        }

        if (shouldDrawDialogueOptions()) {
            if (handleDialogueOptionClick(mx, my)) {
                return;
            }
        }

        if (shouldDrawCurrentDialogueLine()) {
            activeDialogueLineIndex++;
            return;
        }

        if (activeDialogueNode.hasOptions()) {
            return;
        }

        finishDialogue();
    }

    private boolean resolveVisitorNightKill() {
        ArrayList<Guest> visitorsInside = new ArrayList<Guest>();
        ArrayList<Guest> humansInside = new ArrayList<Guest>();

        for (Guest guest : guestManager.getAllGuests()) {
            if (guest == null) {
                continue;
            }

            if (!guest.isInsideHouse()) {
                continue;
            }

            if (guest.isDead()) {
                continue;
            }

            if (guest.isVisitor()) {
                visitorsInside.add(guest);
            } else if (guest.isHuman()) {
                humansInside.add(guest);
            }
        }

        if (visitorsInside.isEmpty()) {
            return false;
        }

        if (humansInside.isEmpty()) {
            return false;
        }

        Guest victim = humansInside.get(random.nextInt(humansInside.size()));

        victim.setDead(true);
        victim.setKilledByVisitor(true);
        victim.setCorpseImageKey(CHARACTER_TRASH_BAG);

        return true;
    }





    private boolean isDialogueShowingLine() {
        if (activeDialogueNode == null) {
            return false;
        }

        return activeDialogueLineIndex < activeDialogueNode.getLineCount();
    }

    private boolean handleDialogueOptionClick(int mx, int my) {
        List<DialogueOption> options = activeDialogueNode.getOptions();

        for (int i = 0; i < options.size(); i++) {
            Rectangle rect = getDialogueOptionRect(i);

            if (isInsideRect(mx, my, rect.x, rect.y, rect.width, rect.height)) {
                chooseDialogueOption(options.get(i));
                return true;
            }
        }

        return false;
    }




    private void chooseDialogueOption(DialogueOption option) {
        if (option == null) {
            return;
        }

        String nextNodeId = option.getNextNodeId();

        if (SPECIAL_INSPECT_FEATURES.equals(nextNodeId)) {
            String guestId = activeGuestId;
            closeDialogue();
            startInspection(guestId);
            return;
        }


        if (SPECIAL_ALLOW_CURRENT_GUEST.equals(nextNodeId)) {
            pendingDialogueResult = RESULT_NIGHT_VISITOR_ALLOW_PREFIX + activeGuestId;
            finishDialogue();
            return;
        }
        if (SPECIAL_JUDGE_ANSWER_YES.equals(nextNodeId)) {
            pendingDialogueResult = RESULT_JUDGE_VISITOR_DECISION + ":yes";
            finishDialogue();
            return;
        }

        if (SPECIAL_JUDGE_ANSWER_NO.equals(nextNodeId)) {
            pendingDialogueResult = RESULT_JUDGE_VISITOR_DECISION + ":no";
            finishDialogue();
            return;
        }

        if (SPECIAL_JUDGE_ANSWER_YES.equals(nextNodeId)) {
            pendingDialogueResult = RESULT_JUDGE_VISITOR_DECISION + ":yes";
            finishDialogue();
            return;
        }

        if (SPECIAL_JUDGE_ANSWER_NO.equals(nextNodeId)) {
            pendingDialogueResult = RESULT_JUDGE_VISITOR_DECISION + ":no";
            finishDialogue();
            return;
        }


        if (SPECIAL_REJECT_CURRENT_GUEST.equals(nextNodeId)) {
            pendingDialogueResult = RESULT_NIGHT_VISITOR_REJECT_PREFIX + activeGuestId;
            finishDialogue();
            return;
        }

        if (option.isEndDialogue()) {
            finishDialogue();
            return;
        }

        if (nextNodeId == null) {
            finishDialogue();
            return;
        }

        goToDialogueNode(nextNodeId);
    }

    private void startInspection(String guestId) {
        if (currentPhase != GamePhase.DAY) {
            return;
        }

        if (currentDay != 3) {
            showMessage("现在还不能检查。");
            return;
        }

        Guest guest = guestManager.getGuest(guestId);

        if (guest == null) {
            return;
        }

        if (guest.isDead()) {
            showMessage("他已经死了。");
            return;
        }

        inspectionActive = true;
        inspectedGuestId = guestId;
        currentInspectionFeature = null;
        currentInspectionImageKey = null;
    }


    private void goToDialogueNode(String nodeId) {
        Guest guest = guestManager.getGuest(activeGuestId);

        if (guest == null) {
            closeDialogue();
            return;
        }

        DialogueNode nextNode;

        if (activeDialogueIsDay) {
            nextNode = guest.getDayDialogueNode(nodeId);
        } else {
            nextNode = guest.getDialogueNode(nodeId);
        }

        if (nextNode == null) {
            finishDialogue();
            return;
        }

        activeDialogueNode = nextNode;
        activeDialogueLineIndex = 0;
    }

    private void finishDialogue() {
        String resultId = pendingDialogueResult;
        String finishedGuestId = activeGuestId;

        closeDialogue();

        handleDialogueResult(resultId, finishedGuestId);
    }


    private void closeDialogue() {
        showDialogue = false;
        activeGuestId = null;
        activeDialogueIsDay = false;
        activeDialogueNode = null;
        activeDialogueLineIndex = 0;
        pendingDialogueResult = null;
    }

    private void handleDialogueResult(String resultId, String guestId) {
        if (resultId == null) {
            return;
        }

        if (RESULT_NEIGHBOR_ENTER_HOUSE.equals(resultId)) {
            resultNeighborEnterHouse();
            return;
        }

        if (RESULT_FINISH_DAY_TALK.equals(resultId)) {
            resultFinishDayTalk(guestId);
            return;
        }

        if (RESULT_DAUGHTER_TAKE_NEIGHBOR.equals(resultId)) {
            resultDaughterTakeNeighbor();
            return;
        }

        if (resultId.startsWith(RESULT_NIGHT_VISITOR_ALLOW_PREFIX)) {
            String allowedGuestId = resultId.substring(RESULT_NIGHT_VISITOR_ALLOW_PREFIX.length());
            resultAllowNightVisitor(allowedGuestId);
            return;
        }

        if (resultId.startsWith(RESULT_NIGHT_VISITOR_REJECT_PREFIX)) {
            String rejectedGuestId = resultId.substring(RESULT_NIGHT_VISITOR_REJECT_PREFIX.length());
            resultRejectNightVisitor(rejectedGuestId);
        }
        if (resultId.startsWith(RESULT_JUDGE_VISITOR_DECISION)) {
            handleJudgeVisitorDecision(resultId);
            return;
        }

    }

    private void handleJudgeVisitorDecision(String resultId) {
        addFlag(FLAG_JUDGE_VISITOR_VISITED);

        boolean answeredYes = resultId.endsWith(":yes");
        boolean answeredNo = resultId.endsWith(":no");

        int humanCountInside = countHumansInsideHouseExcludingPlayer();
        boolean playerIsOnlyHuman = (humanCountInside == 0);

        if (answeredYes) {
            startFlashBlack(0.8, FLASH_GAME_OVER_BY_JUDGE);
            return;
        }

        if (answeredNo) {
            if (playerIsOnlyHuman) {
                startFlashBlack(0.8, FLASH_GAME_OVER_BY_JUDGE);
                return;
            }

            clearOutsideGuest();
            currentScene = SceneType.YARD_NIGHT;
            advanceToNextNightVisitor();
        }
    }

    private int countHumansInsideHouseExcludingPlayer() {
        int count = 0;

        List<Guest> guests = guestManager.getAllGuests();

        for (int i = 0; i < guests.size(); i++) {
            Guest guest = guests.get(i);

            if (guest == null) {
                continue;
            }

            if (!guest.isInsideHouse()) {
                continue;
            }

            if (guest.isDead()) {
                continue;
            }

            if (!guest.isHuman()) {
                continue;
            }

            count++;
        }

        return count;
    }


    private void resultFinishDayTalk(String guestId) {
        if (currentDay == 2 && GUEST_NEIGHBOR.equals(guestId)) {
            addFlag(FLAG_NEIGHBOR_TALKED_MORNING);
            clearStamina();
        }
    }

    private void clearStamina() {
        currentStamina = 0;
    }

    private boolean isStaminaEmpty() {
        return currentStamina <= 0;
    }



    private void resultNeighborEnterHouse() {
        Guest neighbor = guestManager.getGuest(GUEST_NEIGHBOR);

        if (neighbor != null) {
            neighbor.setInsideHouse(true);
            neighbor.setCurrentRoom(DayRoomType.KITCHEN);
        }

        clearOutsideGuest();

        addFlag(FLAG_NEIGHBOR_INSIDE_HOUSE);

        currentScene = SceneType.YARD_NIGHT;
    }


    private void resultFinishDayTalk() {
        if (currentDay == 2 && GUEST_NEIGHBOR.equals(activeGuestId)) {
            addFlag(FLAG_NEIGHBOR_TALKED_MORNING);
            clearStamina();
        }
    }


    private ArrayList<ClickableArea> getActiveClickAreas() {
        ArrayList<ClickableArea> areas = new ArrayList<ClickableArea>();

        if (currentPhase == GamePhase.NIGHT) {
            collectNightClickAreas(areas);
        } else if (currentPhase == GamePhase.DAY) {
            collectDayClickAreas(areas);
        }

        return areas;
    }

    private void collectNightClickAreas(ArrayList<ClickableArea> areas) {
        if (currentScene == SceneType.BEDROOM_NIGHT) {
            collectBedroomNightClickAreas(areas);
            return;
        }

        if (currentScene == SceneType.YARD_NIGHT) {
            collectYardNightClickAreas(areas);
        }
    }

    private void collectBedroomNightClickAreas(ArrayList<ClickableArea> areas) {
        if (hasOutsideGuest()) {
            areas.add(new ClickableArea(
                    ACTION_GO_YARD,
                    1450,
                    260,
                    300,
                    560
            ));
        }

        if (canSleepNow()) {
            areas.add(new ClickableArea(
                    ACTION_SLEEP,
                    250,
                    650,
                    760,
                    330
            ));
        }
    }


    private void collectYardNightClickAreas(ArrayList<ClickableArea> areas) {
        areas.add(new ClickableArea(
                ACTION_OPEN_GATE,
                760,
                220,
                400,
                650
        ));

        if (!hasOutsideGuest()) {
            areas.add(new ClickableArea(
                    ACTION_GO_BEDROOM_NIGHT,
                    60,
                    120,
                    280,
                    80
            ));
        }
    }

    private void collectDayClickAreas(ArrayList<ClickableArea> areas) {
        if (currentScene == SceneType.BEDROOM_DAY) {
            collectBedroomDayClickAreas(areas);
            return;
        }

        if (currentScene == SceneType.HALLWAY_DAY) {
            collectHallwayDayClickAreas(areas);
            return;
        }

        if (currentScene == SceneType.KITCHEN_DAY) {
            collectKitchenDayClickAreas(areas);
            return;
        }

        if (currentScene == SceneType.STORAGE_DAY) {
            collectStorageDayClickAreas(areas);
            return;
        }

        if (currentScene == SceneType.LIVING_ROOM_DAY) {
            collectLivingRoomDayClickAreas(areas);
        }
    }



    private void collectBedroomDayClickAreas(ArrayList<ClickableArea> areas) {
        areas.add(new ClickableArea(
                ACTION_GO_HALLWAY_DAY,
                1450,
                260,
                300,
                560
        ));

        areas.add(new ClickableArea(
                ACTION_DAY_SLEEP,
                250,
                650,
                760,
                330
        ));

        collectVisibleGuestClickAreas(areas, DayRoomType.BEDROOM);
    }


    private void collectHallwayDayClickAreas(ArrayList<ClickableArea> areas) {
        areas.add(new ClickableArea(
                ACTION_GO_KITCHEN_DAY,
                80,
                240,
                320,
                620
        ));

        areas.add(new ClickableArea(
                ACTION_GO_LIVING_ROOM_DAY,
                520,
                220,
                320,
                640
        ));

        areas.add(new ClickableArea(
                ACTION_GO_BEDROOM_DAY,
                980,
                220,
                320,
                640
        ));

        areas.add(new ClickableArea(
                ACTION_GO_STORAGE_DAY,
                1440,
                240,
                320,
                620
        ));
    }




    private void collectKitchenDayClickAreas(ArrayList<ClickableArea> areas) {
        areas.add(new ClickableArea(
                ACTION_GO_HALLWAY_DAY,
                60,
                120,
                280,
                760
        ));

        collectVisibleGuestClickAreas(areas, DayRoomType.KITCHEN);
    }

    private void collectStorageDayClickAreas(ArrayList<ClickableArea> areas) {
        areas.add(new ClickableArea(
                ACTION_GO_HALLWAY_DAY,
                60,
                120,
                280,
                760
        ));

        collectVisibleGuestClickAreas(areas, DayRoomType.STORAGE);
    }

    private void collectLivingRoomDayClickAreas(ArrayList<ClickableArea> areas) {
        areas.add(new ClickableArea(
                ACTION_GO_HALLWAY_DAY,
                60,
                120,
                280,
                760
        ));

        collectVisibleGuestClickAreas(areas, DayRoomType.LIVING_ROOM);
    }




    private void setOutsideGuest(String guestId) {
        outsideGuestId = guestId;
        outsideGuestVisible = false;
    }

    private void clearOutsideGuest() {
        outsideGuestId = null;
        outsideGuestVisible = false;
    }


    private boolean hasOutsideGuest() {
        return outsideGuestId != null;
    }

    private boolean canSleepNow() {
        if (currentPhase != GamePhase.NIGHT) {
            return false;
        }

        if (hasOutsideGuest()) {
            return false;
        }

        if (currentDay == 2 && !hasFlag(FLAG_SECOND_NIGHT_VISITORS_DONE)) {
            return false;
        }

        if (currentDay == 3 && !hasFlag(FLAG_THIRD_NIGHT_VISITORS_DONE)) {
            return false;
        }

        return true;
    }



    private void addFlag(String flag) {
        flags.add(flag);
    }

    private void removeFlag(String flag) {
        flags.remove(flag);
    }

    private boolean hasFlag(String flag) {
        return flags.contains(flag);
    }

    private void showMessage(String text) {
        message = text;
    }

    private void clearMessage() {
        message = "";
    }

    private boolean hasMessage() {
        return message != null && !message.isEmpty();
    }

    private boolean isInsideRect(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    public static void main(String[] args) {
        createGame(new VisitorGame());
    }
}
